export default {
  providers: [
    {
      domain: "https://sweet-stinkbug-98.clerk.accounts.dev",
      applicationID: "convex",
    },
  ],
};
